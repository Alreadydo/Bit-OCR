package nl.hanze.hive;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

// Tests requirement 1.
public class HiveGameTest {
    // Queen Bee tests.
    @Test
    void hasExactlyOneQueenTest() {
        HiveGame hiveGame = new HiveGame();
        int queenAmount;

        queenAmount = hiveGame.getCurrentPlayerTiles().get(Hive.Tile.QUEEN_BEE);

        assertEquals(1, queenAmount);
    }

    @Test
    void hasNotMoreThanOneQueenTest() {
        HiveGame hiveGame = new HiveGame();
        int queenAmount;

        queenAmount = hiveGame.getCurrentPlayerTiles().get(Hive.Tile.QUEEN_BEE);

        assertFalse(queenAmount > 1);
    }

    // Spider tests.
    @Test
    void hasExactlyTwoSpidersTest() {
        HiveGame hiveGame = new HiveGame();
        int spiderAmount;

        spiderAmount = hiveGame.getCurrentPlayerTiles().get(Hive.Tile.SPIDER);

        assertEquals(2, spiderAmount);
    }

    @Test
    void hasNotMoreThanTwoSpidersTest() {
        HiveGame hiveGame = new HiveGame();
        int spiderAmount;

        spiderAmount = hiveGame.getCurrentPlayerTiles().get(Hive.Tile.SPIDER);

        assertFalse(spiderAmount > 2);
    }

    // Beetle tests.
    @Test
    void hasExactlyTwoBeetlesTest() {
        HiveGame hiveGame = new HiveGame();
        int beetleAmount;

        beetleAmount = hiveGame.getCurrentPlayerTiles().get(Hive.Tile.BEETLE);

        assertEquals(2, beetleAmount);
    }

    @Test
    void hasNotMoreThanTwoBeetlesTest() {
        HiveGame hiveGame = new HiveGame();
        int beetleAmount;

        beetleAmount = hiveGame.getCurrentPlayerTiles().get(Hive.Tile.BEETLE);

        assertFalse(beetleAmount > 2);
    }

    // Soldier Ant tests
    @Test
    void hasExactlyThreeSoldierAntsTest() {
        HiveGame hiveGame = new HiveGame();
        int soldierAntAmount;

        soldierAntAmount = hiveGame.getCurrentPlayerTiles().get(Hive.Tile.SOLDIER_ANT);

        assertEquals(3, soldierAntAmount);
    }

    @Test
    void hasNotMoreThanThreeSoldierAntsTest() {
        HiveGame hiveGame = new HiveGame();
        int soldierAntAmount;

        soldierAntAmount = hiveGame.getCurrentPlayerTiles().get(Hive.Tile.SOLDIER_ANT);

        assertFalse(soldierAntAmount > 3);
    }

    // Grasshopper tests
    @Test
    void hasExactlyThreeGrasshoppersTest() {
        HiveGame hiveGame = new HiveGame();
        int grasshopperAmount;

        grasshopperAmount = hiveGame.getCurrentPlayerTiles().get(Hive.Tile.GRASSHOPPER);

        assertEquals(3, grasshopperAmount);
    }

    @Test
    void hasNotMoreThanThreeGrasshoppersTest() {
        HiveGame hiveGame = new HiveGame();
        int grasshopperAmount;

        grasshopperAmount = hiveGame.getCurrentPlayerTiles().get(Hive.Tile.GRASSHOPPER);

        assertFalse(grasshopperAmount > 3);
    }
}
