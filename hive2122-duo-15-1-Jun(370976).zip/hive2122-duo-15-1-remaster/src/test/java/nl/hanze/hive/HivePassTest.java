package nl.hanze.hive;

import static org.junit.jupiter.api.Assertions.*;

import nl.hanze.hive.board.Coords;
import nl.hanze.hive.board.HiveBoard;
import nl.hanze.hive.board.HiveTile;
import org.junit.jupiter.api.Test;

//Requirement 12
public class HivePassTest {
    @Test
    void whiteCanNotPlayAnyPiecesButCanMoveThenPassTest() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();

        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 0));
        hiveGame.getCurrentPlayerTiles().put(Hive.Tile.QUEEN_BEE,hiveGame.getCurrentPlayerTiles().get(Hive.Tile.QUEEN_BEE)-1);

        board.setTileAtPosition(new HiveTile(Hive.Tile.SPIDER, Hive.Player.WHITE), new Coords(-1, 1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SPIDER, Hive.Player.WHITE), new Coords(-2, 2));
        hiveGame.getCurrentPlayerTiles().put(Hive.Tile.SPIDER,hiveGame.getCurrentPlayerTiles().get(Hive.Tile.SPIDER)-2);

        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.WHITE), new Coords(1, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.WHITE), new Coords(2, -2));
        hiveGame.getCurrentPlayerTiles().put(Hive.Tile.BEETLE,hiveGame.getCurrentPlayerTiles().get(Hive.Tile.BEETLE)-2);

        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.WHITE), new Coords(-1, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.WHITE), new Coords(-2, -2));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.WHITE), new Coords(-3, -3));
        hiveGame.getCurrentPlayerTiles().put(Hive.Tile.SOLDIER_ANT,hiveGame.getCurrentPlayerTiles().get(Hive.Tile.SOLDIER_ANT)-3);

        board.setTileAtPosition(new HiveTile(Hive.Tile.GRASSHOPPER, Hive.Player.WHITE), new Coords(1, 1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.GRASSHOPPER, Hive.Player.WHITE), new Coords(2, 2));
        board.setTileAtPosition(new HiveTile(Hive.Tile.GRASSHOPPER, Hive.Player.WHITE), new Coords(3, 3));
        hiveGame.getCurrentPlayerTiles().put(Hive.Tile.GRASSHOPPER,hiveGame.getCurrentPlayerTiles().get(Hive.Tile.GRASSHOPPER)-3);

        hiveGame.setBoard(board);

        assertThrows(Hive.IllegalMove.class, () -> hiveGame.pass());
    }

    @Test
    void blackCanPassWhileNoneMovableAndPlayableTiles() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();
        //Add black spider
        board.setTileAtPosition(new HiveTile(Hive.Tile.SPIDER, Hive.Player.BLACK), new Coords(0, 0));
        //Add white tiles
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SPIDER, Hive.Player.WHITE), new Coords(1, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SPIDER, Hive.Player.WHITE), new Coords(1, 0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.WHITE), new Coords(0, 1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.WHITE), new Coords(-1, 1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.GRASSHOPPER, Hive.Player.WHITE), new Coords(-1, 0));


        hiveGame.setBoard(board);
        hiveGame.nextPlayer();
        hiveGame.getCurrentPlayerTiles().put(Hive.Tile.GRASSHOPPER,hiveGame.getCurrentPlayerTiles().get(Hive.Tile.GRASSHOPPER)-3);
        hiveGame.getCurrentPlayerTiles().put(Hive.Tile.SOLDIER_ANT,hiveGame.getCurrentPlayerTiles().get(Hive.Tile.SOLDIER_ANT)-3);
        hiveGame.getCurrentPlayerTiles().put(Hive.Tile.QUEEN_BEE,hiveGame.getCurrentPlayerTiles().get(Hive.Tile.QUEEN_BEE)-1);
        hiveGame.getCurrentPlayerTiles().put(Hive.Tile.SPIDER,hiveGame.getCurrentPlayerTiles().get(Hive.Tile.SPIDER)-2);
        hiveGame.getCurrentPlayerTiles().put(Hive.Tile.BEETLE,hiveGame.getCurrentPlayerTiles().get(Hive.Tile.BEETLE)-2);

        assertDoesNotThrow(() -> hiveGame.pass());

    }

    @Test
    void whiteCanPassAtTheBeginningOfTheGameTest() throws Hive.IllegalMove {
        HiveGame hiveGame = new HiveGame();
        HiveBoard board = new HiveBoard();
        hiveGame.setBoard(board);
        assertThrows(Hive.IllegalMove.class, () -> hiveGame.pass());
    }

    @Test
    void whiteCanPlayButCantMoveTileThenPassTest() throws Hive.IllegalMove {
        HiveGame hiveGame = new HiveGame();
        HiveBoard board = new HiveBoard();

        //Add black spider
        board.setTileAtPosition(new HiveTile(Hive.Tile.SPIDER, Hive.Player.BLACK), new Coords(0, 0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.GRASSHOPPER, Hive.Player.BLACK), new Coords(0, -3));

        //Add white tiles
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SPIDER, Hive.Player.WHITE), new Coords(1, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SPIDER, Hive.Player.WHITE), new Coords(1, 0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.WHITE), new Coords(0, 1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.WHITE), new Coords(-1, 1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.GRASSHOPPER, Hive.Player.WHITE), new Coords(-1, 0));


        hiveGame.setBoard(board);
        hiveGame.nextPlayer();

        assertThrows(Hive.IllegalMove.class, () -> hiveGame.pass());

    }
}
