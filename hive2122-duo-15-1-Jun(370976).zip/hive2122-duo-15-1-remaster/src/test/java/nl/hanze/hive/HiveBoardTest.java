package nl.hanze.hive;

import nl.hanze.hive.board.Coords;
import nl.hanze.hive.board.HiveBoard;
import nl.hanze.hive.board.HiveTile;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

// Tests requirement 2.
public class HiveBoardTest {
    @Test
    void tileHasExactlySixNeighboursCoordinatesTest() {
        HiveBoard  board;
        ArrayList<Coords> neighbourTileCoordinates;

        board          = new HiveBoard();
        neighbourTileCoordinates = board.getNeighbourCoordinates(new Coords(0,0));

        assertEquals(6, neighbourTileCoordinates.size());
    }
}
