package nl.hanze.hive;
import static org.junit.jupiter.api.Assertions.*;

import nl.hanze.hive.board.Coords;
import nl.hanze.hive.board.HiveBoard;
import nl.hanze.hive.board.HiveTile;
import org.junit.jupiter.api.Test;

//Requirement 7,8,9,10,11 test

public class HiveTileTest {
//  Requirement 7
    @Test
    void whiteSlideBeetleOnceToValidPositionTest() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();
        // White Queen
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 0));
        // Black Queen
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(0, 1));
        // White Beetle
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.WHITE), new Coords(-1, 0));
        // Black Soldier ant
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.BLACK), new Coords(0, 2));

        hiveGame.setBoard(board);

        assertDoesNotThrow(() -> hiveGame.move(-1,0,0,-1));
    }

    @Test
    void whiteSlideBeetleTwiceToValidPositionTest() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();
        // White Queen
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 0));
        // Black Queen
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(0, 1));
        // White Beetle
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.WHITE), new Coords(-1, 0));
        // Black Soldier ant
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.BLACK), new Coords(0, 2));

        hiveGame.setBoard(board);

        assertThrows(Hive.IllegalMove.class, () -> hiveGame.move(-1,0,1,-1));
    }

    @Test
    void whiteSlideBeetleFromOccupiedPositionToOccupiedPosition() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();
        // White Queen
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 0));
        // Black Queen
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(0, 1));
        // White Spider
        board.setTileAtPosition(new HiveTile(Hive.Tile.SPIDER, Hive.Player.WHITE), new Coords(-1, 0));
        // Black Soldier ant
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.BLACK), new Coords(0, 2));
        // White Beetle
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.WHITE), new Coords(-1, 0));

        hiveGame.setBoard(board);

        assertDoesNotThrow(() -> hiveGame.move(-1,0,0,0));

    }


    //Requirement 8
    @Test
    void whiteSlideQueenTwiceToValidPositionTest() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();
        //White queen
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 0));
        hiveGame.getCurrentPlayerTiles().put(Hive.Tile.QUEEN_BEE,0);
        // Black Queen
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(0, 1));
        // White Beetle
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.WHITE), new Coords(-1, 0));
        // White Spider
        board.setTileAtPosition(new HiveTile(Hive.Tile.SPIDER, Hive.Player.WHITE), new Coords(-1, 1));
        // Black Soldier ant
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.BLACK), new Coords(0, 2));
        // Black Spider
        board.setTileAtPosition(new HiveTile(Hive.Tile.SPIDER, Hive.Player.BLACK), new Coords(1, 2));

        hiveGame.setBoard(board);

        assertThrows(Hive.IllegalMove.class, () -> hiveGame.move(0,0,1,1));
    }

    @Test
    void whiteSlideQueenOnceToValidPositionTest() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();
        //White queen
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 0));
        hiveGame.getCurrentPlayerTiles().put(Hive.Tile.QUEEN_BEE,0);
        // Black Queen
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(0, 1));
        // White Beetle
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.WHITE), new Coords(-1, 0));
        // White Spider
        board.setTileAtPosition(new HiveTile(Hive.Tile.SPIDER, Hive.Player.WHITE), new Coords(-1, 1));
        // Black Soldier ant
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.BLACK), new Coords(0, 2));
        // Black Spider
        board.setTileAtPosition(new HiveTile(Hive.Tile.SPIDER, Hive.Player.BLACK), new Coords(1, 2));

        hiveGame.setBoard(board);

        assertDoesNotThrow(() -> hiveGame.move(0,0,1,0));
    }

    @Test
    void whiteSlideQueenToOccupiedTest() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();

        // White Queen.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 0));
        // White Beetle
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.WHITE), new Coords(-1, 1));

        // Black Queen
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(0, 1));

        hiveGame.setBoard(board);

        assertThrows(Hive.IllegalMove.class, () -> hiveGame.move(0, 0, 0, 1));
    }

    // Requirement 9 test
    @Test
    void whiteSoldierAntMovingExactlyOnceToEmptyTileTest() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();
        // Add white tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.WHITE), new Coords(1, 0));

        // Add black tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(0, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.BLACK), new Coords(0, -2));

        hiveGame.setBoard(board);

        assertDoesNotThrow(() -> hiveGame.move(1, 0, 0, 1));
    }

    @Test
    void whiteSoldierAntMovingMoreThanOnceToEmptyTileTest() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();
        // Add white tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.WHITE), new Coords(0, 1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.WHITE), new Coords(1, 0));

        // Add black tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(0, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.BLACK), new Coords(0, -2));

        hiveGame.setBoard(board);

        assertDoesNotThrow(() -> hiveGame.move(1, 0, -1, 2));
    }

    @Test
    void whiteSoldierAntMovingExactlyOnceToOccupiedTileTest() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();
        // Add white tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.WHITE), new Coords(0, 1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.WHITE), new Coords(1, 0));

        // Add black tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(0, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.BLACK), new Coords(0, -2));

        hiveGame.setBoard(board);

        assertThrows(Hive.IllegalMove.class, () -> hiveGame.move(1, 0, 0, 1));
    }

    @Test
    void whiteSoldierAntMovingMoreThanOnceToOccupiedTileTest() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();
        // Add white tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.WHITE), new Coords(-1, 1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.WHITE), new Coords(1, 0));

        // Add black tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(0, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.BLACK), new Coords(0, -2));

        hiveGame.setBoard(board);

        assertThrows(Hive.IllegalMove.class, () -> hiveGame.move(1, 0, -1, 1));
    }

    @Test
    void whiteSoldierAntMovingToSelfTest() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();
        // Add white tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.WHITE), new Coords(1, 0));

        // Add black tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(0, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.BLACK), new Coords(0, -2));

        hiveGame.setBoard(board);

        assertThrows(Hive.IllegalMove.class, () -> hiveGame.move(1, 0, 1, 0));
    }

    @Test
    void whiteSoldierAntMovingToEmptyTileByMovingOverEmptyTileTest() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();
        // Add white tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.WHITE), new Coords(1, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.WHITE), new Coords(0, 1));

        // Add black tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(0, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.BLACK), new Coords(0, -2));

        hiveGame.setBoard(board);

        assertThrows(Hive.IllegalMove.class, () -> hiveGame.move(0, 1, 1, 1));
    }

    @Test
    void whiteSoldierAntMovingToEmptyTileByMovingOverOccupiedTileTest() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();
        // Add white tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.WHITE), new Coords(1, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.WHITE), new Coords(0, 1));

        // Add black tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(0, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.BLACK), new Coords(0, -2));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.BLACK), new Coords(2, -1));

        hiveGame.setBoard(board);

        assertThrows(Hive.IllegalMove.class, () -> hiveGame.move(0, 1, 2, -1));
    }

    @Test
    void whiteSoldierAntMovingToEmptyTileByMovingOverOccupiedTileBlockedByBlackTest() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();
        // Add white tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.WHITE), new Coords(1, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.WHITE), new Coords(0, 1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.WHITE), new Coords(2, -2));

        // Add black tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(0, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.BLACK), new Coords(0, -2));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.BLACK), new Coords(-1, 0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.BLACK), new Coords(2, -1));

        hiveGame.setBoard(board);

        assertDoesNotThrow(() -> hiveGame.move(0, 1, 3, -2));
    }

    //Requirement 10 test
    @Test
    void whiteSpiderMovingExactlyThreeTilesToEmptyTileTest() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();

        // Add white tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.WHITE), new Coords(0, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.WHITE), new Coords(0, -2));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SPIDER, Hive.Player.WHITE), new Coords(1, 0));

        // Add black tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(-1, 0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.BLACK), new Coords(-2, 0));

        hiveGame.setBoard(board);

        assertDoesNotThrow(() -> hiveGame.move(1, 0, 1, -3));
    }

    @Test
    void whiteSpiderMovingExactlyThreeTilesToOccupiedTileTest() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();

        // Add white tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.WHITE), new Coords(0, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.WHITE), new Coords(0, -2));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SPIDER, Hive.Player.WHITE), new Coords(1, 0));

        // Add black tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(0, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.BLACK), new Coords(0, -2));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.BLACK), new Coords(1, -3));

        hiveGame.setBoard(board);

        assertThrows(Hive.IllegalMove.class, () -> hiveGame.move(1, 0, 1, -3));
    }

    @Test
    void whiteSpiderMovingMoreThanThreeTilesToEmptyTileTest() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();

        // Add white tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.WHITE), new Coords(0, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.WHITE), new Coords(0, -2));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.WHITE), new Coords(0, -3));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SPIDER, Hive.Player.WHITE), new Coords(1, 0));

        // Add black tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(0, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.BLACK), new Coords(0, -2));

        hiveGame.setBoard(board);

        assertThrows(Hive.IllegalMove.class, () -> hiveGame.move(1, 0, 1, -4));
    }

    @Test
    void whiteSpiderMovingMoreThanThreeTilesToOccupiedTileTest() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();

        // Add white tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.WHITE), new Coords(0, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.WHITE), new Coords(0, -2));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.WHITE), new Coords(0, -3));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SPIDER, Hive.Player.WHITE), new Coords(1, 0));

        // Add black tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(0, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.BLACK), new Coords(0, -2));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.BLACK), new Coords(1, -4));

        hiveGame.setBoard(board);

        assertThrows(Hive.IllegalMove.class, () -> hiveGame.move(1, 0, 1, -4));
    }

    @Test
    void whiteSpiderMovingLessThanThreeTilesToEmptyTileTest() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();

        // Add white tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.WHITE), new Coords(0, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.WHITE), new Coords(0, -2));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SPIDER, Hive.Player.WHITE), new Coords(1, 0));

        // Add black tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(0, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.BLACK), new Coords(0, -2));

        hiveGame.setBoard(board);

        assertThrows(Hive.IllegalMove.class, () -> hiveGame.move(1, 0, 1, -2));
    }

    @Test
    void whiteSpiderMovingLessThanThreeTilesToOccupiedTileTest() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();

        // Add white tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.WHITE), new Coords(0, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.WHITE), new Coords(0, -2));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SPIDER, Hive.Player.WHITE), new Coords(1, 0));

        // Add black tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(0, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.BLACK), new Coords(0, -2));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.BLACK), new Coords(1, -2));

        hiveGame.setBoard(board);

        assertThrows(Hive.IllegalMove.class, () -> hiveGame.move(1, 0, 1, -2));
    }

    @Test
    void whiteSpiderMovingExactlyThreeTilesBySlidingOverEmptyTilesTest() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();

        // Add white tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SPIDER, Hive.Player.WHITE), new Coords(0, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.WHITE), new Coords(0, -2));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SPIDER, Hive.Player.WHITE), new Coords(1, 0));

        hiveGame.setBoard(board);

        assertDoesNotThrow(() -> hiveGame.move(1, 0, 1, -3));
    }

    //Requirement 11
    @Test
    void whiteGrasshopperJumpStraightLineOverTwoTilesToEmptyPositionAfterAnotherTile() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();

        // Add white tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.GRASSHOPPER, Hive.Player.WHITE), new Coords(-1, 0));
        // Add black tile
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(1, 0));

        hiveGame.setBoard(board);

        assertDoesNotThrow(() -> hiveGame.move(-1, 0, 2, 0));
    }

    @Test
    void whiteGrasshopperJumpOverTwoTilesWithoutStraightLineToEmptyPositionAfterAnotherTile() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();
        // Add white tiles
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.GRASSHOPPER, Hive.Player.WHITE), new Coords(0, 0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.WHITE), new Coords(1, -2));

        hiveGame.setBoard(board);

        assertThrows(Hive.IllegalMove.class, () -> hiveGame.move(0, 0, 1, -3));
    }

    @Test
    void whiteGrasshopperJumpOverOneTileStraightLineToOccupiedPositionAfterAnotherTile() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();

        // Add white tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.GRASSHOPPER, Hive.Player.WHITE), new Coords(-1, 0));
        // Add black tile
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(1, 0));

        hiveGame.setBoard(board);

        assertThrows(Hive.IllegalMove.class, () -> hiveGame.move(-1, 0, 1, 0));

    }

    @Test
    void whiteGrasshopperJumpOverOneTileStraightLineToEmptyPositionAfterAnotherTile() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();

        // Add white tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.GRASSHOPPER, Hive.Player.WHITE), new Coords(1, 0));

        hiveGame.setBoard(board);

        assertDoesNotThrow(() -> hiveGame.move(1, 0, -1, 0));

    }

    @Test
    void whiteGrasshopperMoveToAdjacentPositionWithoutJump() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();

        // Add white tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.GRASSHOPPER, Hive.Player.WHITE), new Coords(-1, 0));
        // Add black tile
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(1, 0));

        hiveGame.setBoard(board);

        assertThrows(Hive.IllegalMove.class, () -> hiveGame.move(-1, 0, -1, 1));
    }

    @Test
    void whiteGrasshopperJumpOverEmptyField() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();

        // Add white tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.GRASSHOPPER, Hive.Player.WHITE), new Coords(-1, 0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SPIDER, Hive.Player.WHITE), new Coords(1, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.WHITE), new Coords(1, -2));
        //Add black tiles
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(-1, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.BLACK), new Coords(0, -2));


        hiveGame.setBoard(board);

        assertThrows(Hive.IllegalMove.class, () -> hiveGame.move(-1, 0, 2, -3));
    }

    @Test
    void whiteGrasshopperMovingToOwnPositionTest() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();
        // Add white tiles.
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, -1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.GRASSHOPPER, Hive.Player.WHITE), new Coords(0, 0));

        hiveGame.setBoard(board);

        assertThrows(Hive.IllegalMove.class, () -> hiveGame.move(0, 0, 0, 0));
    }
}
