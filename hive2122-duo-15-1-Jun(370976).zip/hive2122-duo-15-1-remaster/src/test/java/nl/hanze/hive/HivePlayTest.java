package nl.hanze.hive;
import nl.hanze.hive.board.Coords;
import nl.hanze.hive.board.HiveBoard;
import nl.hanze.hive.board.HiveTile;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
//Requirement 4 test
public class HivePlayTest{
    @Test
    void whitePlayTwoQueenBeeTest() throws Hive.IllegalMove {
        HiveGame hiveGame = new HiveGame();
        //White plays Queen Bee
        hiveGame.play(Hive.Tile.QUEEN_BEE, 0, 0);
        //Black plays Queen Bee
        hiveGame.play(Hive.Tile.QUEEN_BEE, 0, 1);

        assertThrows(Hive.IllegalMove.class, () -> hiveGame.play(Hive.Tile.QUEEN_BEE, 1,0 ));
    }

    @Test
    void whitePlayTileAtOccupiedPositionTest() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();
        //White plays Queen Bee
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 0));
        //Black plays Queen Bee
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(0, 1));

        hiveGame.setBoard(board);

        assertThrows(Hive.IllegalMove.class,()-> hiveGame.play(Hive.Tile.GRASSHOPPER, 0,1));
    }

    @Test
    void whitePlayTileAwayFromExistedTileTest() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();
        //White plays Queen Bee
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 0));
        //Black plays Queen Bee
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(0, 1));

        hiveGame.setBoard(board);

        assertThrows(Hive.IllegalMove.class,()-> hiveGame.play(Hive.Tile.GRASSHOPPER, 0,-3));
    }


    @Test
    void whitePlayTileOnlyNextToOpponentTileTest() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();
        //White plays Queen Bee
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 0));
        //Black plays Queen Bee
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(0, 1));

        hiveGame.setBoard(board);

        assertThrows(Hive.IllegalMove.class,()->hiveGame.play(Hive.Tile.BEETLE, 0, 2));
    }

    @Test
    void whitePlayForthTileWhileQueenNotPlayedYetTest() throws Hive.IllegalMove {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();

        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.WHITE), new Coords(0, 0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.WHITE), new Coords(0, 1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.GRASSHOPPER, Hive.Player.WHITE), new Coords(0, 2));

        hiveGame.setBoard(board);

        assertThrows(Hive.IllegalMove.class,()->hiveGame.play(Hive.Tile.GRASSHOPPER, 0, 4));
    }

}
