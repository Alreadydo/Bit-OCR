package nl.hanze.hive;
import nl.hanze.hive.board.Coords;
import nl.hanze.hive.board.HiveBoard;
import nl.hanze.hive.board.HiveTile;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
//Requirement 6 test
public class HiveSlideTest{
    @Test
    void whiteSlideTileToEmptyPositionTest() {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();
        //White queen
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 1));
        // Black Queen
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(0, 0));
        //Black Beetle
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.BLACK), new Coords(1, 0));
        hiveGame.setBoard(board);

        assertDoesNotThrow(() -> hiveGame.move(0, 1, 1, 1));
    }

    @Test
    void whiteSlideTileToOccupiedPositionTest()  {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();
        //White queen
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 1));
        // White beetle
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.WHITE), new Coords(1, 1));

        // Black Queen
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(0, 0));
        // Black Beetle
        board.setTileAtPosition(new HiveTile(Hive.Tile.BEETLE, Hive.Player.BLACK), new Coords(1, 0));

        hiveGame.setBoard(board);

        assertDoesNotThrow(()-> hiveGame.move(1,1,0,1));
    }

    @Test
    void whiteDoesInvalidSlideBetweenTwoTilesTest()  {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();
        // White queen bee
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(1, -1));
        // Black queen bee
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(0, -1));
        // Black beetle
        board.setTileAtPosition(new HiveTile(Hive.Tile.SPIDER, Hive.Player.WHITE), new Coords(1, 0));

        Coords illegalCoordinate = new Coords(0,0);
        hiveGame.setBoard(board);

        assertFalse(board.getSlideAbleCoordinates(new Coords(1,-1)).contains(illegalCoordinate));
    }

    @Test
    void whiteSlideWhileNotStayingContactTest() {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();
        // White queen bee
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, -1));

        // Black queen bee
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(1, -1));
        // White soldier ant
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.WHITE), new Coords(-1, 0));
        // Black soldier ant
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.BLACK), new Coords(1, 0));
        // White soldier ant
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.WHITE), new Coords(-1, 1));
        hiveGame.setBoard(board);
        Coords illegalCoordinate = new Coords(0,1);



        assertFalse(board.getSlideAbleCoordinates(new Coords(-1,1)).contains(illegalCoordinate));
    }

    @Test
    void whiteSlideWhileStayingContactTest()  {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();
        // White queen bee
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 1));

        // Black queen bee
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(1, -1));
        // White soldier ant
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.WHITE), new Coords(-1, 0));
        // Black soldier ant
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.BLACK), new Coords(1, 0));
        // White soldier ant
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.WHITE), new Coords(1, 1));
        // White Spider
        board.setTileAtPosition(new HiveTile(Hive.Tile.SPIDER, Hive.Player.WHITE), new Coords(0, 0));

        hiveGame.setBoard(board);
        Coords legalCoordinate = new Coords(0,1);

        assertDoesNotThrow(()-> board.getSlideAbleCoordinates(new Coords(-1,1)).contains(legalCoordinate));
    }
}
