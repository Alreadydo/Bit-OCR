package nl.hanze.hive;

import nl.hanze.hive.board.Coords;
import nl.hanze.hive.board.HiveBoard;
import nl.hanze.hive.board.HiveTile;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
//Requirement 3 test
public class HiveGameCourseTest{

    @Test
    void whiteHasFirstMoveTest() {
        Hive.Player currentPlayer;
        HiveGame hiveGame = new HiveGame();

        currentPlayer = hiveGame.getCurrentPlayer();
        assertEquals(Hive.Player.WHITE, currentPlayer);
    }

    @Test
    void blackDoesNotHaveFirstMoveTest() {
        HiveGame hiveGame = new HiveGame();
        Hive.Player currentPlayer;

        currentPlayer = hiveGame.getCurrentPlayer();
        assertNotEquals(Hive.Player.BLACK, currentPlayer);
    }

    @Test
    void whiteCanPlayTileTest() {
        HiveGame hiveGame = new HiveGame();
        assertDoesNotThrow(() -> hiveGame.play(Hive.Tile.QUEEN_BEE, 0, 0));
    }

    @Test
    void isTurnOfBlackAfterWhitePlayTileTest() throws Hive.IllegalMove {
        Hive.Player currentPlayer;
        HiveGame hiveGame = new HiveGame();

        currentPlayer = hiveGame.getCurrentPlayer();
        hiveGame.play(Hive.Tile.QUEEN_BEE, 0, 0);
        assertNotEquals(null, currentPlayer);
    }

    @Test
    void whiteCanMoveTileTest() throws Hive.IllegalMove{
       HiveGame hiveGame = new HiveGame();
       HiveBoard board = new HiveBoard();
       //Play White Queen
       board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 0));
       //Play Black Queen
       board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(0, 1));

       hiveGame.setBoard(board);

       assertDoesNotThrow(() -> hiveGame.move(0,0,1,0));
    }

    @Test
    void isTurnOfBlackAfterWhiteMoveTileTest() throws Hive.IllegalMove{
        Hive.Player currentPlayer;
        HiveGame hiveGame = new HiveGame();
        HiveBoard board = new HiveBoard();

        currentPlayer = hiveGame.getCurrentPlayer();
        // White queen at 0, 0
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0, 0));

        // Black queen at 0, 1
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(0, 1));

        hiveGame.setBoard(board);
        hiveGame.move(0,0,1,0);

        assertNotEquals(null,currentPlayer);
    }

    @Test
    void singleMoveSetWonGameTest() throws Hive.IllegalMove{
        HiveGame hiveGame = new HiveGame();
        Hive.Player currentPlayer;

        currentPlayer = hiveGame.getCurrentPlayer();
        HiveBoard board = new HiveBoard();

        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0,0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(0,-1));

        hiveGame.setBoard(board);

        assertFalse(hiveGame.isWinner(currentPlayer));
    }

    @Test
    void currentPlayerHasWonTest() {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();

        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0,0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(0,-1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.BLACK), new Coords(1,-1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.BLACK), new Coords(-1,0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.BLACK), new Coords(1,0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.BLACK), new Coords(-1,1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.BLACK), new Coords(0,1));

        hiveGame.setBoard(board);

        assertTrue(hiveGame.isWinner(Hive.Player.BLACK));
    }

    @Test
    void GameDrawTest() {
        HiveGame hiveGame = new HiveGame();
        HiveBoard board = new HiveBoard();
        //hiveGame.setBoard(board);

        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0,0));
        //Set Black tiles
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(0,-1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.BLACK), new Coords(1,-1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.BLACK), new Coords(-1,0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.BLACK), new Coords(1,0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.BLACK), new Coords(-1,1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.BLACK), new Coords(0,1));
        //Set White tiles
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.WHITE), new Coords(-1,-1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.WHITE), new Coords(1,-2));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.WHITE), new Coords(0,-2));

        hiveGame.setBoard(board);
        assertTrue(hiveGame.isDraw());
    }

    @Test
    void whiteDoesNotWinWhileGameDrawTest() {
        HiveBoard board = new HiveBoard();
        HiveGame hiveGame = new HiveGame();



        //Set Black tiles
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.BLACK), new Coords(0,-1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.BLACK), new Coords(1,-1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.BLACK), new Coords(-1,0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.BLACK), new Coords(1,0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.BLACK), new Coords(-1,1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.BLACK), new Coords(0,1));
        //Set White tiles
        board.setTileAtPosition(new HiveTile(Hive.Tile.QUEEN_BEE, Hive.Player.WHITE), new Coords(0,0));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.WHITE), new Coords(-1,-1));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.WHITE), new Coords(1,-2));
        board.setTileAtPosition(new HiveTile(Hive.Tile.SOLDIER_ANT, Hive.Player.WHITE), new Coords(0,-2));

        hiveGame.setBoard(board);

        assertFalse(hiveGame.isWinner(Hive.Player.WHITE));
    }
}
