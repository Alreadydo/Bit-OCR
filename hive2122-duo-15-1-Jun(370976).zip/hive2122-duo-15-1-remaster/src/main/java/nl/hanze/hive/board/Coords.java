package nl.hanze.hive.board;

public class Coords {
    public int q;
    public int r;

    public boolean equals(Object o) {
        if (!(o instanceof Coords))
            return false;

        Coords c = (Coords) o;
        return c.q == q && c.r == r;
    }

    public Coords(int q, int r) {
        super();

        this.q = q;
        this.r = r;
    }

    public int hashCode() {
        int qNegative = (q < 0)? 1 : 0;
        int rNegative = (r < 0)? 1 : 0;

        return Integer.parseInt(Math.abs(q) + qNegative + "0" + Math.abs(r) + rNegative);
    }

    public int distance(Coords coords) {
        int Q = Math.abs(this.q-coords.q);
        int R = Math.abs(this.r-coords.r);
        int D = Math.abs((this.q-coords.q)*-1 - (this.r-coords.r)-1);

        return Math.max(Math.max(Q, R), D);
    }

    @Override
    public String toString() {
        return "Coords{" +
                "q=" + q +
                ", r=" + r +
                '}';
    }
}
