package nl.hanze.hive.strategies;

import nl.hanze.hive.board.Coords;
import nl.hanze.hive.board.HiveBoard;

import java.util.ArrayList;

public class BeetleStrategic implements TileValidMovesStrategic {

    @Override
    public ArrayList<Coords> getValidMoves(HiveBoard board, Coords source) {
        return board.getSlideAbleCoordinates(source);
    }
}
