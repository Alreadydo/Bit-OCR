package nl.hanze.hive.strategies;

import nl.hanze.hive.board.Coords;
import nl.hanze.hive.board.HiveBoard;

import java.util.ArrayList;

public class QueenBeeStrategic implements TileValidMovesStrategic {

    @Override
    public ArrayList<Coords> getValidMoves(HiveBoard board, Coords source) {
        ArrayList <Coords> queenValidMoves = new ArrayList<>();
        ArrayList <Coords> validMoves = board.getSlideAbleCoordinates(source);
        for(Coords coords:validMoves) {
            if(board.isTilePositionEmpty(coords)){
                queenValidMoves.add(coords);
            }
        }
        return queenValidMoves;
    }
}
