package nl.hanze.hive;

import nl.hanze.hive.board.Coords;
import nl.hanze.hive.board.HiveBoard;
import nl.hanze.hive.board.HiveTile;

import java.nio.charset.CoderResult;
import java.util.*;
// requirement 1,3
public class HiveGame implements Hive {
    private final EnumMap<Tile, Integer> whiteTiles;
    private final EnumMap<Tile, Integer> blackTiles;
    private       HiveBoard              board;
    private       Hive.Player            currentPlayer;
    public HiveGame() {
        this.whiteTiles = new EnumMap<>(Hive.Tile.class);
        this.blackTiles = new EnumMap<>(Hive.Tile.class);
        this.board      = new HiveBoard();
        this.currentPlayer = Player.WHITE;

        this.initializeTileMap(this.whiteTiles);
        this.initializeTileMap(this.blackTiles);
    }

    @Override
    public void play(Tile tile, int q, int r) throws IllegalMove {
        Coords coords = new Coords(q,r);
        HiveTile hiveTile = new HiveTile(tile,currentPlayer);
        int amountOfPlayedTilesByPlayer = this.board.getPlayedPiecesCountByPlayer(this.getCurrentPlayer());
        // requirement 4a
        if(!currentPlayerHasTile(tile)){
            throw new IllegalMove("Current Player does not have this tile");
        }
        // requirement 4b
        if(!board.isTilePositionEmpty(coords)){
            throw new IllegalMove("Current position is occupied");
        }
        // requirement 4c
        if(!isBoardEmpty() && !tileHasNeighbours(coords)){
            throw new IllegalMove("Invalid play");
        }
        // requirement 4d
        if(board.getBoardSize()>=2 && !neighboursHaveTheSameColor(coords)){
            throw new IllegalMove("Neighbours do not have same color");
        }
        // requirement 4e
        if(amountOfPlayedTilesByPlayer == 3 && !queenBeeIsPlayed() && tile !=Tile.QUEEN_BEE){
            throw new IllegalMove("Queen Bee not played yet");
        }
        board.setTileAtPosition(hiveTile,coords);
        getCurrentPlayerTiles().put(tile,getCurrentPlayerTiles().get(tile)-1);
        this.nextPlayer();
    }

    @Override
    public void move(int fromQ, int fromR, int toQ, int toR) throws IllegalMove {
        Coords source = new Coords(fromQ,fromR);
        Coords des    = new Coords(toQ,toR);
        // requirement 5b
        if(!queenBeeIsPlayed()) {
            throw new IllegalMove("Queen bee is not played yet");
        }
        // requirement 5a
        if(!isTileFromCurrentPlayer(source)) {
            throw new IllegalMove("The tile is not from current player");
        }
        // requirement 5c
        if(!tileHasNeighbours(des)) {
            throw new IllegalMove("The tile does not contact another tile after move");
        }
        // requirement 5d
        if(board.isLinkBreak(source,des)) {
            throw new IllegalMove(String.format("Moving tile from %s to %s breaks the connection",source,des));
        }
        // requirement 6
        if(!board.isValidMove(source,des)){
            throw new IllegalMove("This type of tile can not move like this way");
        }

        this.moveTile(source,des);
        this.nextPlayer();
    }
    //Requirement 12
    @Override
    public void pass() throws IllegalMove {
        if(this.currentPlayerTilesHasLeft() || currentPlayerCanMoveTile() ) {
            throw new IllegalMove("Current Player still can play or move tile");
        }
        this.nextPlayer();
    }

    @Override
    public boolean isWinner(Player player) {
        Hive.Player opponent = (player == Player.WHITE) ? Player.BLACK : Player.WHITE;
        return isQueenSurrounded(opponent) && !isQueenSurrounded(player);
    }

    @Override
    public boolean isDraw() {
        Hive.Player opponent = (currentPlayer == Player.WHITE) ? Player.BLACK : Player.WHITE;
        return isQueenSurrounded(currentPlayer) && isQueenSurrounded(opponent);
    }

    /**
     * This function returns the current player's tiles.
     *
     * @return Current player's tiles.
     */
    public EnumMap<Tile, Integer> getCurrentPlayerTiles() {
        if (currentPlayer == Player.WHITE) {
            return whiteTiles;
        } else {
            return blackTiles;
        }
    }

    public HiveBoard getBoardClass() {
        return board;
    }

    public void setBoard(HiveBoard board) {
        this.board = board;
    }

    /**
     * This function will initialize a EnumMap for a player.
     *
     * @param tileMap The EnumMap to initialize.
     */
    private void initializeTileMap(EnumMap<Hive.Tile, Integer> tileMap) {
        tileMap.put(Tile.QUEEN_BEE, 1);
        tileMap.put(Tile.SPIDER, 2);
        tileMap.put(Tile.BEETLE, 2);
        tileMap.put(Tile.GRASSHOPPER, 3);
        tileMap.put(Tile.SOLDIER_ANT, 3);
    }

    public void nextPlayer() {
        this.currentPlayer = (this.currentPlayer == Player.WHITE) ? Player.BLACK : Player.WHITE;
    }
    public boolean isQueenSurrounded(Player player) {
        Coords queenPosition = this.board.getPlayerQueenPosition(player);
        if(null == queenPosition) {
            return false;
        }
        ArrayList<Coords> neighbours = board.getNeighbourCoordinates(queenPosition);
        for (Coords neighbour: neighbours) {
                if ( board.getTileAtPosition(neighbour)== null) {
                return false;
            }
        }
        return true;
    }
    public Hive.Player getCurrentPlayer() {
        return currentPlayer;
    }

    public boolean currentPlayerHasTile(Tile tile) {
        if(getCurrentPlayerTiles().get(tile)==0){
            return false;
        }
        return true;
    }



    public boolean isBoardEmpty() {
       return board.getBoardSize()==0;
    }

    public boolean tileHasNeighbours(Coords coords) {
        return board.getNeighbourTilesAtPosition(coords).size()!=0;
    }

    public boolean neighboursHaveTheSameColor(Coords coords) {
        for(HiveTile neighbour: board.getNeighbourTilesAtPosition(coords)) {
            if(neighbour.getOwner()!=currentPlayer) {
                return false;
            }
        }
        return true;
    }

    public int amountOfCurrentPlayerTiles() {
        int sum =0;
        for(Map.Entry<Tile,Integer>entry: getCurrentPlayerTiles().entrySet()){
            sum += entry.getValue();
        }
        return sum;
    }

    public boolean queenBeeIsPlayed() {
        for(Map.Entry<Coords, HiveTile> entry: board.getBoard().entrySet()) {
            Coords coords = entry.getKey();
            HiveTile hiveTile = entry.getValue();
            if(hiveTile.getOccupant()==Tile.QUEEN_BEE & hiveTile.getOwner()==getCurrentPlayer()) {
                return true;
            }
        }
        return false;
    }

    public boolean isTileFromCurrentPlayer(Coords coords) {
        if(this.board.getTileAtPosition(coords).getOwner()!=currentPlayer){
            return false;
        }
        return true;
    }

    public void moveTile(Coords source, Coords des) throws Hive.IllegalMove  {
        HiveTile tile = board.removeTileAtPosition(source);
        if(tile ==null) {
            throw new Hive.IllegalMove("There is no tile to move");
        }
        board.setTileAtPosition(tile,des);
    }

    public boolean currentPlayerTilesHasLeft() {
        boolean hasLeft = false;
        if(amountOfCurrentPlayerTiles()!=0) {
            hasLeft = true;
        }
        return hasLeft;
    }

    public boolean currentPlayerCanMoveTile() {
        ArrayList<Coords>coordsOfTilesOfCurrentPlayer = new ArrayList<>();
        for(Coords coords: board.getBoard().keySet()){
           if(board.getTileAtPosition(coords).getOwner()==currentPlayer) {
               coordsOfTilesOfCurrentPlayer.add(coords);
           }
        }
        if(board.getBoardSize()==0){
            return true;
        }
        for(Coords tileCoordsOfCurrentPlayer: coordsOfTilesOfCurrentPlayer) {
            if(board.getBoardSize()!=0 && board.getValidMoves(tileCoordsOfCurrentPlayer).size()!=0) {
                return true;
            }
        }

        return false;
    }
}
