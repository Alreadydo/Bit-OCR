package nl.hanze.hive.strategies;

import nl.hanze.hive.board.Coords;
import nl.hanze.hive.board.HiveBoard;

import java.util.ArrayList;

public interface TileValidMovesStrategic {
    ArrayList<Coords> getValidMoves(HiveBoard board,Coords source);
}
