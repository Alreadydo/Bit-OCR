package nl.hanze.hive.board;

import nl.hanze.hive.Hive;

import java.util.Stack;

public class HiveTile {
    private Stack<Hive.Tile> occupants;
    private Stack<Hive.Player> owners;
    public HiveTile(Hive.Tile occupant, Hive.Player owner) {
        this.occupants  = new Stack<>();
        this.owners     = new Stack<>();

        this.occupants.add(occupant);
        this.owners.add(owner);
    }

    public Hive.Tile getOccupant() {
        return this.occupants.peek();
    }

    public Hive.Player getOwner() {
        return this.owners.peek();
    }
    public int getOccupantCount() {
        return this.occupants.size();
    }
}
