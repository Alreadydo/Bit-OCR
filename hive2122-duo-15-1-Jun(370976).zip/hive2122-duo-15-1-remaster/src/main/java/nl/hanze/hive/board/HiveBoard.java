package nl.hanze.hive.board;

import nl.hanze.hive.Hive;
import nl.hanze.hive.HiveGame;
import nl.hanze.hive.strategies.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Stack;
// requirement 2
public class HiveBoard {
    private final HashMap<Coords, HiveTile> board;

    public HiveBoard() {
        this.board = new HashMap<>();
    }

    public HiveTile getTileAtPosition(Coords coords) {
        return this.board.get(coords);
    }

    public ArrayList<HiveTile> getNeighbourTilesAtPosition(Coords coords) {
        ArrayList<HiveTile> neighbours = new ArrayList<>();

        for(Coords neighbourCoordinate :getNeighbourCoordinates(coords)){
            HiveTile tileAtCoordinate = getTileAtPosition(neighbourCoordinate);
            if(tileAtCoordinate!=null){
                neighbours.add(tileAtCoordinate);
            }
        }

        return neighbours;
    }
    public void setTileAtPosition(HiveTile tile,Coords coords) {
        this.board.put(coords, tile);
    }

    public Coords getPlayerQueenPosition(Hive.Player player) {
        for (Coords coords : this.board.keySet()) {
            HiveTile tile = this.board.get(coords);

            if (tile.getOccupant() == Hive.Tile.QUEEN_BEE && tile.getOwner() == player) {
                return coords;
            }
        }
        return null;
    }

    public int getBoardSize(){
        return board.size();
    }

    public HashMap<Coords, HiveTile> getBoard() {
        return board;
    }

    public int getPlayedPiecesCountByPlayer(Hive.Player player) {
        int playedTileCountByPlayer = 0;

        for (HiveTile tile : this.getBoard().values()) {
            if (tile.getOwner() == player)
                playedTileCountByPlayer++;
        }

        return playedTileCountByPlayer;
    }



    public boolean isTilePositionEmpty(Coords coords) {
        return  this.getTileAtPosition(coords)==null;
    }

    private void getRecursiveTileNeighbours(Stack<HiveTile> stack, HiveTile ignoreTile, Coords coords) {
        if (stack.contains(this.getTileAtPosition(coords))) {
            return;
        }

        stack.add(this.getTileAtPosition(coords));

        for (HiveTile neighbour : this.getNeighbourTilesAtPosition(coords)) {
            if (stack.contains(neighbour) || neighbour == ignoreTile)
                continue;

            Coords neighbourCoordinate =getTilePosition(neighbour);
            if(neighbourCoordinate == null) {
                continue;
            }
            getRecursiveTileNeighbours(stack,ignoreTile,neighbourCoordinate);
        }
    }

    public ArrayList<Coords> getNeighbourCoordinates(Coords coords) {
        ArrayList<Coords> neighboursCoordinates = new ArrayList<>();

        neighboursCoordinates.add(new Coords(coords.q, coords.r - 1));
        neighboursCoordinates.add(new Coords(coords.q+1, coords.r - 1));
        neighboursCoordinates.add(new Coords(coords.q-1, coords.r));
        neighboursCoordinates.add(new Coords(coords.q+1, coords.r));
        neighboursCoordinates.add(new Coords(coords.q-1, coords.r+1));
        neighboursCoordinates.add(new Coords(coords.q, coords.r + 1));

        return neighboursCoordinates;
    }

    public Coords getTilePosition(HiveTile tile) {
        for (Coords coords: board.keySet()) {
            if(board.get(coords).equals(tile)){
                return coords;
            }
        }
        return null;
    }

    public boolean isLinkBreak(Coords source, Coords des) {
        if(source.equals(des)){
            return false;
        }
        Stack<HiveTile> preSwapStack  = new Stack<>();
        Stack<HiveTile> postSwapStack = new Stack<>();

        getRecursiveTileNeighbours(preSwapStack, null, source);
        getRecursiveTileNeighbours(postSwapStack, this.getTileAtPosition(source),des);

        if(!this.isTilePositionEmpty(des)) {
            return preSwapStack.size() != postSwapStack.size()+1;
        }else {
            return preSwapStack.size() != postSwapStack.size();
        }
    }

    public HiveTile removeTileAtPosition(Coords coords) {
        return board.remove(coords);
    }

    public ArrayList<Coords> getCoordinatesOfExitsNeighbourTile(Coords source) {
        ArrayList<Coords> coordinatesOfExitsNeighbourTile = new ArrayList<>();

        for(HiveTile neighbour: getNeighbourTilesAtPosition(source)) {

            Coords neighbourCoordinate = getTilePosition(neighbour);
            for(Coords coords:getNeighbourCoordinates(neighbourCoordinate)) {
                coordinatesOfExitsNeighbourTile.add(coords);
            }
        }
        return coordinatesOfExitsNeighbourTile;
    }
    // requirement 6a,6b
    public boolean canSlide(Coords source, Coords des) {
        int heightOfA =0;
        int heightOfB =0;
        int heightOfN1 =0;
        int heightOfN2 =0;
        HiveTile tileA = getTileAtPosition(source);
        HiveTile tileB = getTileAtPosition(des);
        if(tileA!=null){
            heightOfA = tileA.getOccupantCount();
        }
        if(tileB!=null){
            heightOfB = tileB.getOccupantCount();
        }
        ArrayList<Coords> n1Andn2 = getN1AndN2(source,des);
        Coords N1 = n1Andn2.get(0);
        Coords N2 = n1Andn2.get(1);
        HiveTile tileN1 = getTileAtPosition(N1);
        HiveTile tileN2 = getTileAtPosition(N2);
        if (tileN1!=null){
            heightOfN1=tileN1.getOccupantCount();
        }
        if (tileN2!=null){
            heightOfN2=tileN2.getOccupantCount();
        }
        return Math.min(heightOfN1,heightOfN2)<=Math.max(heightOfA-1,heightOfB);

    }

    public ArrayList<Coords> getN1AndN2(Coords source, Coords des) {
        HashSet<Coords> setA = new HashSet<>(getNeighbourCoordinates(source));
        HashSet<Coords>setB = new HashSet<>(getNeighbourCoordinates(des));
        setA.retainAll(setB);

        return new ArrayList<>(setA);
    }
    // requirement 6c
    public boolean isDesPositionNeighbourOfNeighbour(Coords source, Coords des) {
        if(getTileAtPosition(des)!=null){
            return true;
        }
        return getCoordinatesOfExitsNeighbourTile(source).contains(des);

    }

    public ArrayList<Coords> getSlideAbleCoordinates(Coords source) {
        ArrayList<Coords> slideAbleCoordinates = new ArrayList<>();
        ArrayList<Coords> neighbourCoordinates = getNeighbourCoordinates(source);
        for(Coords neighbourCoordinate:neighbourCoordinates) {
            if(canSlide(source,neighbourCoordinate) && isDesPositionNeighbourOfNeighbour(source,neighbourCoordinate)) {
                slideAbleCoordinates.add(neighbourCoordinate);
            }
        }
        return slideAbleCoordinates;
    }

    public boolean isValidMove(Coords source, Coords des) {
        return getValidMoves(source). contains(des);
    }
    // requirement 7,8,9,10,11,12
    public ArrayList<Coords> getValidMoves(Coords source) {
        ArrayList<Coords> validMoves;
        TileValidMovesStrategic tileValidMovesStrategic;
        Hive.Tile tile = getTopTileFromOccupiedPosition(source);

        switch (tile) {
            case QUEEN_BEE:
                tileValidMovesStrategic = new QueenBeeStrategic();
                break;
            case SPIDER:
                tileValidMovesStrategic = new SpiderStrategic();
                break;
            case GRASSHOPPER:
                tileValidMovesStrategic = new GrasshopperStrategic();
                break;
            case SOLDIER_ANT:
                tileValidMovesStrategic = new SoldierAntStrategic();
                break;
            default:
                tileValidMovesStrategic = new BeetleStrategic();
        }

        validMoves = tileValidMovesStrategic.getValidMoves(this,source);
        return validMoves;
    }

    public Hive.Tile getTopTileFromOccupiedPosition(Coords source) {
        Hive.Tile tile = getTileAtPosition(source).getOccupant();
        return tile;
    }




}
