package nl.hanze.hive.strategies;

import nl.hanze.hive.board.Coords;
import nl.hanze.hive.board.HiveBoard;
import nl.hanze.hive.board.HiveTile;

import java.util.ArrayList;

public class SpiderStrategic implements TileValidMovesStrategic {
    ArrayList<Coords> visited = new ArrayList<>();
    ArrayList<Coords> spiderValidMoves = new ArrayList<>();
    @Override
    public ArrayList<Coords> getValidMoves(HiveBoard board, Coords source) {
        HiveTile removedTile = board.removeTileAtPosition(source);

        getSpiderValidMoves(source,board,0);

        board.setTileAtPosition(removedTile,source);

        System.out.println("Spider"+spiderValidMoves);
        return spiderValidMoves;
    }
    public void getSpiderValidMoves(Coords from, HiveBoard board, int depth) {
        ArrayList<Coords> validMoves=  board.getSlideAbleCoordinates(from);
        visited.add(from);
        if(depth>=3) {
            spiderValidMoves.add(from);
            return;
        }
        if(validMoves.size() ==0) {
            return;
        }
        for(Coords coords: validMoves) {
            if(board.getTileAtPosition(coords)==null && !visited.contains(coords)) {
                getSpiderValidMoves(coords,board,depth+1);
            }
        }
    }
}
