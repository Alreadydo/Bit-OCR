package nl.hanze.hive.strategies;

import nl.hanze.hive.board.Coords;
import nl.hanze.hive.board.HiveBoard;

import java.nio.charset.CoderResult;
import java.util.ArrayList;

public class GrasshopperStrategic implements TileValidMovesStrategic {
    @Override
    public ArrayList<Coords> getValidMoves(HiveBoard board, Coords source) {
        ArrayList<Coords>grasshopperValidMoves = new ArrayList<>();

        //Loop through all 6 direction
        // 1. Top right
        int q = source.q+1;
        int r = source.r-1;
        Coords possibleValidMoves = null;
        boolean canJump = false;

        while(board.getTileAtPosition(new Coords(q,r))!=null) {
            canJump = true;
            q+=1;
            q-=1;
        }
        if(canJump) {
            possibleValidMoves = new Coords(q,r);
        }
        if(possibleValidMoves!=null) {
            grasshopperValidMoves.add(possibleValidMoves);
        }

        // 2. Right
        q = source.q+1;
        r = source.r;
        canJump = false;
        while(board.getTileAtPosition(new Coords(q,r))!=null) {
            canJump = true;
            q+=1;
        }
        if(canJump) {
            possibleValidMoves = new Coords(q,r);
        }
        if(possibleValidMoves!=null) {
            grasshopperValidMoves.add(possibleValidMoves);
        }

        // 3. Bottom right
        q = source.q;
        r = source.r+1;
        canJump = false;

        while(board.getTileAtPosition(new Coords(q,r))!=null) {
            canJump = true;
            r+=1;
        }
        if(canJump) {
            possibleValidMoves = new Coords(q,r);
        }
        if(possibleValidMoves!=null) {
            grasshopperValidMoves.add(possibleValidMoves);
        }

        //4 . Bottom left
        q = source.q-1;
        r = source.r+1;
        canJump = false;

        while(board.getTileAtPosition(new Coords(q,r))!=null) {
            canJump = true;
            q-=1;
            r+=1;
        }
        if(canJump) {
            possibleValidMoves = new Coords(q,r);
        }
        if(possibleValidMoves!=null) {
            grasshopperValidMoves.add(possibleValidMoves);
        }

        //5. Left
        q = source.q-1;
        r = source.r;
        canJump = false;

        while(board.getTileAtPosition(new Coords(q,r))!=null) {
            canJump = true;
            q-=1;
        }
        if(canJump) {
            possibleValidMoves = new Coords(q,r);
        }
        if(possibleValidMoves!=null) {
            grasshopperValidMoves.add(possibleValidMoves);
        }

        // 6. Top left
        q = source.q;
        r = source.r-1;
        canJump = false;

        while(board.getTileAtPosition(new Coords(q,r))!=null) {
            canJump = true;
            r-=1;
        }
        if(canJump) {
            possibleValidMoves = new Coords(q,r);
        }
        if(possibleValidMoves!=null) {
            grasshopperValidMoves.add(possibleValidMoves);
        }

        return grasshopperValidMoves;
    }

}
