package nl.hanze.hive.strategies;

import nl.hanze.hive.board.Coords;
import nl.hanze.hive.board.HiveBoard;

import java.nio.charset.CoderResult;
import java.util.ArrayList;
//Requirement 9
public class SoldierAntStrategic implements TileValidMovesStrategic {
    ArrayList<Coords> visited = new ArrayList<>();
    @Override
    public ArrayList<Coords> getValidMoves(HiveBoard board, Coords source) {
        getSoldierAntValidMoves(source,board);
        visited.remove(source);

        //System.out.println("SolderAnt:"+visited);
        return visited;
    }
    public void getSoldierAntValidMoves(Coords from, HiveBoard board) {
        ArrayList<Coords> soldierAntValidMoves = board.getSlideAbleCoordinates(from);
        visited.add(from);
        if(soldierAntValidMoves.size() ==0) {
            return;
        }
        for(Coords coords: soldierAntValidMoves) {
            if(board.getTileAtPosition(coords)==null && !visited.contains(coords)) {
                getSoldierAntValidMoves(coords,board);
            }
        }
    }
}
